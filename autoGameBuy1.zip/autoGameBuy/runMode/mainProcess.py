#!/usr/bin/env python
#-*- coding:utf-8 -*-

#该函数实现构建多个线程或是进行来进行购买的操作

from threading import Thread
from webs.buyweb import (app)
from queue import Queue

taskQueue = Queue()

if __name__ == '__main__':
    app.run(debug=True)
