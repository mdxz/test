#!/usr/bin/env python
#-*- coding:utf-8 -*-

# -*- coding:utf-8 -*-
from PIL import Image
from io import BytesIO
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import cv2
import os
import numpy as np
import copy
import time
from pytesseract import *
import re
from logger.log import autobuyLogger

basePath  = os.path.dirname(os.path.dirname(__file__)) + "//pictures/"

def get_screenshot(driver):
    autobuyLogger.info("in get_screenshot......................................")
    # 获得截屏
    screenshot = driver.get_screenshot_as_png()
    # 将截屏转换为数字信息
    screenshot = Image.open(BytesIO(screenshot))
    # 返回截屏
    return screenshot

def get_postion(wait):
    """
    获取位置信息：
    :return:
    """
    autobuyLogger.info("in get_postion......................................")
    # 第一步：找到已经加载的验证码图片
    img = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR,"#UpdatePanel1>.login_cap>div>div>img")))
    time.sleep(2)
    # 第二步：返回图片的位置对象
    location = img.location
    autobuyLogger.info("location = {}".format(location))
    # 第三步：返回图片位置大小对象
    size = img.size
    autobuyLogger.info("size = {}".format(size))
    # 第四部：获得图片坐标信息，位置信息
    # top, bottom, left, right = int(location['y']), int(location['y'] + size['height']), int(location['x']), int(
    #     location['x'] + size['width'])
    left = location['x']
    top = location['y']
    width = left + size['width']
    hight = top + size['height']
    # 第五步：返回图片的位置信息
    return (left, top, width, hight)

def get_gesst_img(name,driver,wait):
    """
    :param name:
    :return:
    """
    autobuyLogger.info("in get_gesst_img......................................")
    # 获取验证码图片第一步是截屏整个屏幕
    screenshot = get_screenshot(driver)
    # 获取验证码图片第二不是获取图片的位置信息
    left, top, width, hight = get_postion(wait)
    autobuyLogger.info("left, top, width, hight = {}".format((left, top, width, hight)))
    # 按照位置信息和整个图片获得想要的图片
    captcha = screenshot.crop((left, top, width, hight))
    # 保存图片以便查看图片的正确性
    captcha.save(name)
    #返回图片路径
    return name

def saveNumberCodeImage(count,driver,wait):
    """
    该函数实现的是刷新页面，然后截取保存图片
    :param count:
    :param driver:
    :param wait:
    :return:
    """
    #这里在获取验证码图片之前，为了满足在解析验证码的时候可能的不正确的情况，需要多次解析验证码，所以，这里在获取验证码之前先刷新验证码
    #刷新验证码:首先找到刷新按钮
    autobuyLogger.info("in dealVCode......................................")
    driver.maximize_window()
    try:
        pass
        #点击刷新按钮，刷新验证码
        try:
            pass
        except:
            autobuyLogger.exception("点击刷新验证码按钮失败!")
    except:
        autobuyLogger.exception("找寻 刷新验证码 按钮失败")
    autobuyLogger.info("成功的刷新验证码图片!")
    # 驱动浏览器获得验证码图片，并保存到指定的目录下面
    originalImagPath = basePath + "capture22_{}.png".format(count)
    picPath = get_gesst_img(originalImagPath,driver,wait)
    return (picPath, driver, wait)

if __name__=='__main__':
    #因为识别率不是100%，所以这里需要一个循环处理方式，当经过各种方式处理以后，如果返回的文本不是6位的数字的话，点击更换验证码再处理
    #处理的次数暂时定位5次
    autobuyLogger.info("开始运行driver......")
    driver = webdriver.Chrome()
    url = "https://member.mycard520.com.tw/Login/MyCardMemberLogin.aspx?ReturnUrl=%2fMemberLoginService%2fdefault.aspx%3fAuthCode%3d811B50D65B75491AA442CE42D8DB9FB3&AuthCode=811B50D65B75491AA442CE42D8DB9FB3"
    wait = WebDriverWait(driver, 20)
    driver.get(url)
    autobuyLogger.info("driver 运行完毕。。。。。")
    # driver.find_elements_by_link_text()

    (text, driver, wait) = saveNumberCodeImage(0, driver,wait)
    autobuyLogger.info("##########################################")
    autobuyLogger.info(text)

