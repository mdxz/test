#!/usr/bin/env python
#-*- coding:utf-8 -*-


from PIL import Image
from io import BytesIO
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import cv2
import os
import numpy as np
import copy
import time
from pytesseract import *
import re



driver = webdriver.Chrome()
wait = WebDriverWait(driver,10)
driver.get("https://www.baidu.com/")

buttons  = driver.find_elements_by_css_selector("#u1>.mnav:nth-child(1)")
print(buttons)
print(buttons[0].text)
buttons2 = wait.until(EC.presence_of_element_located((
    By.CSS_SELECTOR, "#u1>.mnav:nth-child(1)"
)))
print(buttons)
print(buttons[0].text)
driver.close()
