#!/usr/bin/env python
#-*- coding:utf-8 -*-


import os
import logging
import logging.config as log_conf

log_dir = os.path.dirname(os.path.dirname(__file__)) + "\\logs"

if not os.path.exists(log_dir):
    os.mkdir(log_dir)


autobuylogpath = os.path.join(log_dir,"autoBuy.log")


#配置信息
log_config = {
    'version':1.0,
    'formatters':{
        'detail':{
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            'datefmt': "%Y-%m-%d %H:%M:%S"
        },
        'simple':{
            'format':'%(name)s - %(levelname)s - %(message)s'
        }
    },
    'handlers':{
        'console':{
            'class': 'logging.StreamHandler',
            'level': 'INFO',
            'formatter': 'detail'
        },
        'autobuy_log':{
            'class': 'logging.handlers.RotatingFileHandler',
            'maxBytes': 1024*1024*5,
            'backupCount':10,
            'filename':autobuylogpath,
            'level': 'INFO',
            'formatter': 'detail',
            'encoding': 'utf-8'
        },

    },
    'loggers':{
        'autobuylogger':{
            'handlers': ['console', 'autobuy_log'],
            'level': 'DEBUG',
        },
    }
}

#加载配置信息
log_conf.dictConfig(log_config)

#生成日志记录器对象
autobuyLogger = logging.getLogger("autobuylogger")
