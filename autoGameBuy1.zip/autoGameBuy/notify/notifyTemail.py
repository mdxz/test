#!/usr/bin/env python
#-*- coding:utf-8 -*-

#该模块实现的是通知用户，现在购买状态：其通知的原理是：一直保持通知进程或是线程运转：每个一定的时间从orderinfors取出用户信息，通过时间starttime来判断，进行两次通知，一次是2分钟内，一次是5分钟内

##SMTP只有的有smtplib和email两个模块，email负责构造邮件，smtplib负责邮件发送
import smtplib
from email.mime.text import MIMEText
from email.utils import formataddr
from conf.config import (loginfeedback,buyfeedback)
from conf.config import (emailSeverAccount,emailSeverPassword)
import traceback
import time
from db.AutoBuyDB import AutoDB
from logger.log import autobuyLogger



def emailNotify(emailReciver, productinfor, orderstatus, backupinfo):
    """

    :param email: 发邮件的目的邮件箱
    :param orderstatus: 发送的购买状态
    :param backupinfo: 发送的购买备注信息
    :return:该函数实现的是向某个特定邮箱发送邮件的功能
    """
    autobuyLogger.info("发件人: {}".format(emailSeverAccount))
    autobuyLogger.info("收件人: {}".format(emailReciver))
    ret = True
    try:
        #
        mailContents = "您购买的产品 {} 现在的购买状态是  {}, 阶段是 {}".format(productinfor,orderstatus,backupinfo)
        # 定义邮件msg：MIMEText指向需要发送的邮件的内容
        msg = MIMEText(mailContents, 'plain', 'utf-8')
        msg['From'] = formataddr(["自动购买平台", emailSeverAccount])  # 括号里的对应发件人邮箱昵称、发件人邮箱账号
        msg['To'] = formataddr(["收件人昵称", emailReciver])  # 括号里的对应收件人邮箱昵称、收件人邮箱账号
        msg['Subject'] = "自动购买状态告知"  # 邮件的主题，也可以说是标题
        # 定义邮件服务器对象
        server = smtplib.SMTP_SSL("smtp.qq.com", 465)  # 发件人邮箱中的 SMTP 服务器，端口是465
        # 使用邮件服务器对象登录，发送邮件
        server.login(emailSeverAccount, "rknprnilzluojgdg")  # 括号中对应的是发件人邮箱账号、授权码:授权码是在QQ邮箱中操作设置获得
        #因为每个人员发送的内容可能不一样，所以这里针对每个用户这单独发送，不采取一次全部发送
        server.sendmail(emailSeverAccount, [emailReciver,], msg.as_string())  # 括号中对应的是发件人邮箱账号、收件人邮箱账号、发送邮件
        server.quit()  # 关闭连接
    except Exception:  # 如果 try 中的语句没有执行，则会执行下面的 ret=False
        ret = False
        traceback.print_exc()
        autobuyLogger.exception("发送邮件出现问题!")
    return ret

def checkAndSendEmailsOneMinite():
    autobuyLogger.info("into one minitue")
    #处理一分钟的事情
    oneminiteContents = ""
    try:
        oneminiteContents = AutoDB.buytrace_oneminitescheck()
    except:
        pass
    #如果没有对应的内容的话，则不做任何的处理
    if oneminiteContents == "" or len(oneminiteContents)  == 0:
        pass

    else:
        for oneminiteContent in oneminiteContents:
            buyer = oneminiteContent[0]
            productinfor = oneminiteContent[1]
            orderstatus = oneminiteContent[2]
            backupinfo = oneminiteContent[3]
            oneflag = emailNotify(buyer,productinfor,orderstatus,backupinfo)
            #在发送邮件成功的情况下，重新设置标记
            if oneflag:
                AutoDB.buytrace_resetoneflag(buyer)
            else:
                autobuyLogger.info("一分钟邮件发送: To  {}  失败!".format(buyer))

def checkAndSendEmailsFiveMinite():
    autobuyLogger.info("into 5 迷你图恩")
    #处理一分钟的事情
    fiveminiteContents = ""
    try:
        fiveminiteContents = AutoDB.buytrace_fiveminitescheck()
    except:
        pass
    #如果没有对应的内容的话，则不做任何的处理
    if fiveminiteContents == "" or len(fiveminiteContents) == 0:
        pass
    else:
        for oneminiteContent in fiveminiteContents:
            buyer = oneminiteContent[0]
            productinfor = oneminiteContent[1]
            orderstatus = oneminiteContent[2]
            backupinfo = oneminiteContent[3]
            oneflag = emailNotify(buyer,productinfor,orderstatus,backupinfo)
            #在发送邮件成功的情况下，重新设置标记
            if oneflag:
                AutoDB.buytrace_resetfiveflag(buyer)
            else:
                autobuyLogger.info("5分钟邮件发送: To  {}  失败!".format(buyer))

def mainEmail():
    autobuyLogger.info("开启检测程序")
    count = 0
    while True:
        time.sleep(60)
        count = count + 1
        #调用一分钟
        checkAndSendEmailsOneMinite()
        #调用5分钟
        checkAndSendEmailsFiveMinite()
        #判断一下是否需要调用每隔 30 分钟 需要调用一次的
        if count >= 30:
            #返回的是跟踪账户中存在超过30分钟的账户信息，不管成功还是失败!
            buyers = ""
            try:
                buyers = AutoDB.buytrace_halfhourscheck()
                count = 0
            except:
                pass
            if buyers == "":
                autobuyLogger.info("每隔30分钟的检测中，没有需要清理的账户信息!")
            else:
                for buyer in buyers:
                    AutoDB.buytrace_deletebuyer(buyer)

if __name__ == '__main__':
    # ret = emailNotify("460288492@qq.com","TM_1革命","购买中","登录成功")
    # if ret:
    #     print("邮件发送成功")
    #     #在邮件发送成功以后，重新设置标志
    # else:
    #     print("邮件发送失败")
    mainEmail()