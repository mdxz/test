#!/usr/bin/env python
#-*- coding:utf-8 -*-

###该模块实现建立一个网站对于产品购买过程的控制：起流程逻辑是：

from gevent import monkey
from gevent.pywsgi import WSGIServer
from flask import Flask,session,redirect,url_for,escape
from flask import request
import time
from buy.autoBuy import (getLogin,inputEmailVcode,buyProcess)
from buy.dealorder import (getOrderStatus,checkBuyProcessStatus)
# from db.gamedb import (saveBuyProcessStartStatus)
from db.AutoBuyDB import AutoDB
from logger.log import autobuyLogger
monkey.patch_all()


app = Flask(__name__, static_url_path='')
app.secret_key = '12345'
count= 1

global verifyEmail
#driver,wait始终保存的是当前最新的状态
global driver
global wait


def worngDB():
    """
    该函数实现的是当进行数据操作的时候如果连接不上等原因，被调用
    :return:
    """
    autobuyLogger.info(" 系统发生数据库错误!")
    return """
        后台系统错误,请联系管理人员或是重新登录!
        <a href="http://127.0.0.1:5000">重新登录</a>
    """

@app.route("/", methods=['GET','POST'])
def home():
    if   'username' in session:
        redirect(url_for('logout'))
    # if  'username' in session:
    #     return  '''
    #         欢迎 {} 登录订单管理平台
    #         <a href="http://127.0.0.1:5000/orderdeal">订单管理中心</a>
    #         <a href="http://127.0.0.1:5000/logout">退出登录</a>
    #     '''.format(session['username'])
    return '''
            欢迎来到自动购买系统！请输入origin平台的登录账户和密码!
            <form action="/mysignin" method="post">
            <p>用户名：<input name="username"></p>
            <p>密码：  <input name="password" type="password"></p>
            <p><button type="submit">登陆</button></p>
            </form>
    '''

#当在首页输入账号，密码，订单号以后，跳转的页面处理
@app.route("/mysignin", methods=['POST'])
def mysignin():
    global driver
    global wait
    global verifyEmail
    #获得在登录页面传入的参数
    username = request.form['username']
    password = request.form['password']
    # originLoginStatus = "worngnet"
    #在调用登录之前，先保存跟踪信息
    try:
        #还有一种情况需要处理：就是之前就有username对应的购买信息？那该怎么处理？？？
        AutoDB.buytarce_savebuytrace(username,"暂无","暂无","购买进行中","启动Orgin平台登录!")
    except:
        #如果在保存信息的时候由于网络或是数据库本身的原因不能进行保存的时候的处理方式 ？这里是不做处理
        pass
    #这里调用登录origin平台函数登录函数
    returnoriginLoginStatus = getLogin(username,password)
    autobuyLogger.info("returnoriginLoginStatus={}".format(returnoriginLoginStatus))

    #
    #1： 使用账号和密码判断是否能够登录origin平台：调用接口一共返回4种状态：
    #    状态一： 服务器网络有问题，IP被封或是网络不好 originLoginStatus = "worngnet"
    if  returnoriginLoginStatus[0] == "loginworngnet":
        #当在登录的时候，如果出现错误，从跟踪表中删除账户信息
        try:
            AutoDB.buytrace_deletebuyer(username)
        except:
            autobuyLogger.info("在登录因为网路失败删除跟踪账户信息的时候，失败!")
        #因为在前面已经删除了信息，所以直接提示跳转到主页而不是先经过logout,后到达主页
        return '''
            网络异常!
            <a href="http://127.0.0.1:5000">重新登录购买!</a>
        '''
    #    状态二：originLoginStatus = "worngaccount": 账号密码错误或是服务器网络有问题，
    #            返回失败提示重新输入账号密码，订单号信息
    elif returnoriginLoginStatus[0] == "loginworngaccount":
        #在密码错误的情况下，从跟踪表中删除账户信息
        try:
            AutoDB.buytrace_deletebuyer(username)
        except:
            autobuyLogger.info("在登录因为账号密码错误登录失败 删除跟踪账户信息的时候，失败!")
        return '''
            你输入的账户或是密码有误，请重新登录!
            <a href="http://127.0.0.1:5000">重新登录购买!</a>
        '''
    #   状态三： originLoginStatus = "success"： origin平台登录成功，然后跳转到输入订单号的页面
    elif returnoriginLoginStatus[0] == "loginsuccess":
        #在登录成功的情况下，更新跟踪账户信息
        try:
            AutoDB.buytrace_updatebuytrace(username,"暂无","暂无","购买进行中","不需要验证登录origin成功!")
        except:
            autobuyLogger.info("在登录成功后更新跟踪账户信息的时候，失败!")
        driver = returnoriginLoginStatus[1]
        wait = returnoriginLoginStatus[2]
        return redirect(url_for('inputordernumber'))
    #   状态四： originLoginStatus = "verification"： 需要填入验证码状态，跳转到输入验证码的页面
    #   originLoginStatus保存的是返回的发送验证码的邮箱
    else:
        #在输入验证码之前更新跟踪状态
        try:
            AutoDB.buytrace_updatebuytrace(username,"暂无","暂无","购买进行中","登录账号,密码无误,登录验证码验证中!")
        except:
            autobuyLogger.info("在登录账号验证码无误情况下处理验证码时更新跟踪账户信息的时候，失败!")
        verifyEmail = returnoriginLoginStatus[0]
        driver = returnoriginLoginStatus[1]
        wait = returnoriginLoginStatus[2]
        return redirect(url_for('inputverification'))

@app.route("/inputverification",methods=['GET','POST'])
def inputverification():
    if 'username' in session:
        #先在origin平台执行一些列操作到输入验证码步骤
        # verifyEmail = "xxx"
        global verifyEmail
        return '''
             你的账户在origin平台进行了绑定，需要输入验证码，验证码已经发送
             {}邮箱，请检查，然后输入验证码！
            <form action="/dealverification" method="post">
            <p>验证码：<input name="vcode"></p>
            <p><button type="submit">确定</button></p>
            </form>
        '''.format(verifyEmail)

@app.route("/dealverification", methods=['POST'])
def dealverification():
    if 'username' in session:
        global driver
        global wait
        vcode = request.form['vcode']
        verifStatusInfor = inputEmailVcode(vcode,driver,wait)
        verifStatus = verifStatusInfor[0]
        #这里调用输入验证码函数
        #调用函数输入验证，返回返回输入后的状态：分为三种状态
        # 状态一： 网络出现问题 verifStatus = "worngnet"
        if verifStatus == "inputemailvcodeworngnet":
            #需要删除跟踪表信息
            try:
                AutoDB.buytrace_deletebuyer(session['username'])
            except:
                autobuyLogger.info("在验证码处理阶段由于网络问题删除跟踪账户信息的时候，失败!")
            return '''
                    购买服务器异常，请重新登录或是联系 xxxx
                    <a href="http://127.0.0.1:5000">重新登录购买!</a>
                '''
        # 状态二：验证失败 verifStatus = "veriffail"
        if verifStatus == "inputemailvcodefail":
            #????????这里暂时不确定，当验证码验证失败的时候，是完全重新执行一遍登录验证了还是再另外发送验证码即继续验证。这里暂时当做继续验证
            try:
                AutoDB.buytrace_deletebuyer(session['username'])
            except:
                autobuyLogger.info("在登录的时候输入验证码失败时删除跟踪账户信息的时候，失败!")
            return '''
                验证失败，请重新验证!
                <a href="http://127.0.0.1:5000/inputverification">重新输入验证码</a>
                <a href="http://127.0.0.1:5000">重新登录购买!</a>
            '''
        # 状态三：验证成功跳转到正确页面,则是验证成功verifStatus = "verifsuccess"
        # 然后跳转到订单页面输入订单号
        if verifStatus == "inputemailvcodesuccess":
            #输入验证码后登录成功，更新信息
            try:
                AutoDB.buytrace_updatebuytrace(session['username'], "暂无", "暂无","购买进行中", "输入验证码以后登录成功!")
            except:
                autobuyLogger.info("在输入验证码以后登录成功后更新跟踪账户信息的时候，失败!")
            driver = verifStatusInfor[1]
            wait = verifStatusInfor[2]
            return redirect(url_for('inputordernumber'))

@app.route("/inputordernumber", methods=['POST','GET'])
def inputordernumber():
    if 'username' in session:
        return '''
                    成功的登录origin平台，请输入订单号开始购买!购买状态请关注你的邮箱！
                    <form action="/orderdeal" method="post">
                    <p>订单号：<input name="ordernumber"></p>
                    <p><button type="submit">确定</button></p>
                    </form>
                '''

@app.route("/orderdeal", methods=['POST'])
def orderdeal():
    if 'username' in session:
        global driver
        global wait
        ordernumber = request.form['ordernumber']
        #在天猫中查询......
        #返回一个元组，包含订单状态和产品
        orderstates = None
        try:
            orderstates = getOrderStatus(ordernumber)
        except:
            return '''
                    根据订单号从天猫店铺中获取 订单 {} 信息 是失败!
                   <a href="http://127.0.0.1:5000/inputordernumber">重新输入订单号</a>
                   <a href="http://127.0.0.1:5000/logout">退出购买!</a>
                '''.format(ordernumber)

        #通过订单号在天猫平台上查询该订单号的状态：分为三种
        #状态2： 订单错误，在天猫中查询不到该订单的消息
        if orderstates[0] == "noorder":
            return '''
                        没有查询到订单 {} 信息，请重新输入需要查询的订单号
                        <a href="http://127.0.0.1:5000/inputordernumber">输入订单号</a>
                        <a href="http://127.0.0.1:5000/logout">退出购买!</a>
                    '''.format(ordernumber)
        #状态3： 该订单信息存在，但是还没有付款，所以不能进行购买操作
        if orderstates[0] == "ordernopay":
            return '''
                订单 {} 付款没有完成，请先进行付款.然后重新输入订单信息
                <a href="http://127.0.0.1:5000/inputordernumber">输入订单号</a>
                <a href="http://127.0.0.1:5000/logout">退出购买!</a>
            '''.format(ordernumber)
        # 状态1： 该订单在天猫中有信息，且已经完成付款，两类操作： 保存订单信息到数据库
        #        对该订单进行自动化购买操作
        # 应该在这里添加一个连接跳转
        if orderstates[0] == "ordersuccess":
            # 获取对应的需要操作的信息.
            product = orderstates[1]
            orderstatus = "购买进行中......"
            backupinfo = "开始购买!"

            #1. 当确定某个订单已经付款成功以后,首先需要进行的是避免重复的购买，所以首先查看该订单再后台数据库有没有对应的记录:
            orederDBStatus = AutoDB.orderInfor_checkOrderInfor(ordernumber)
            #当返回的内容为空""的时候，说明该订单是第一次进行购买，不做任何的处理，打印日志即可
            if len(orederDBStatus) == 0:
                autobuyLogger.info("订单 {} 之前没有进行过购买!".format(ordernumber))
                try:
                    AutoDB.buytrace_updatebuytrace(session['username'], ordernumber, product, "购买进行中", "登录成功且成功获取到购买订单,开始购买")
                    # AutoDB.orderInfor_saveBuyProcessStartStatus(ordernumber, product, "shitouyouxiang@163.com", orderstatus,backupinfo)
                    AutoDB.orderInfor_saveBuyProcessStartStatus(ordernumber, product, session['username'], orderstatus,backupinfo)
                except:
                    return '''
                          购买过程中网络出现出现问题!
                          <a href="http://127.0.0.1:5000/inputordernumber">重新输入订单号</a>
                          <a href="http://127.0.0.1:5000/logout">退出购买!</a>
                    '''
            #如果数据库中有对应的订单信息，但是给出的是购买失败，那么可以继续再次购买!并更新订单在数据库中的信息
            elif orederDBStatus[0][5] == "失败":
                autobuyLogger.info("订单 {} 之前进行过购买但是  购买  失败! 现在继续 重新 购买操作 !".format(ordernumber))
                try:
                    AutoDB.buytrace_updatebuytrace(session['username'], ordernumber, product, "购买进行中", "登录成功且成功获取到购买订单,开始购买")
                    AutoDB.orderInfor_updateOrderDBInfor(ordernumber,orderstatus,backupinfo)
                except:
                    return '''
                         购买过程中出现问题!
                         <a href="http://127.0.0.1:5000/inputordernumber">重新输入订单号</a>
                         <a href="http://127.0.0.1:5000/logout">退出购买!</a>
                   '''
            #如果数据库中的信息显示的是购买成功，那么则立即返回之前购买成功，不要重新购买的信息
            elif orederDBStatus[0][5] == "成功":
                autobuyLogger.info("订单 {} 已经成功的进行购买！ 请不要重复购买!".format(ordernumber))
                return '''
                           订单 {} 之前已经成功购买，不能重复进行购买!
                           <a href="http://127.0.0.1:5000/inputordernumber">重新输入订单号</a>
                           <a href="http://127.0.0.1:5000/logout">退出购买!</a>
                     '''.format(ordernumber)
            # 否则剩下的是正在购买中....，如果在正在购买中的话，提醒，然后和成功返回一样
            else:
                autobuyLogger.info("订单 {} 正在购买中.....!  请不要重复购买!".format(ordernumber))
                return '''
                                       订单 {} 正在购买中......！不能重复进行购买!
                                       <a href="http://127.0.0.1:5000/inputordernumber">重新输入订单号</a>
                                       <a href="http://127.0.0.1:5000/logout">退出购买!</a>
                                 '''.format(ordernumber)

            #2. 进行自动化购买........
            #最好将购买的过程作为异步的方式，同步不好:这里使用queue来实现异步
            #将参数构成的元组放到队列中
          #   #这里的目前的处理方式是：先把任务放到队列中...
          #   temptask = ("shitouyouxiang@163.com", ordernumber, product, driver, wait)
          #   taskQueue.put(temptask)
          #
          #   #显示正在购买中，然后让用户选择继续购买或是查询订单的购买状态
          #   return '''
          #       购买正在进行中............
          #       <a href="http://127.0.0.1:5000/">返回登录页面继续购买</a>
          #       <a href="http://127.0.0.1:5000/checkorderstatus">查询订单购买状态</a>
          # '''
            #调用购买函数
            buyProcess("shitouyouxiang@163.com", ordernumber, product, driver, wait)


@app.route("/checkorderstatus", methods=["GET",'POST'])
def checkOrderStatus():
    return '''
                欢迎来到订单查询系统！请输入需要查询的订单号
                <form action="/getorderstatus" method="post">
                <p>订单号：<input name="ordernumber"></p>
                <p><button type="submit">查询</button></p>
                </form>
        '''

@app.route("/getorderstatus", methods=['POST'])
def getorderstatus():
    ordernumber = request.form['ordernumber']
    orderstatus = checkBuyProcessStatus(ordernumber)
    if orderstatus == "beforepay":
        return '''
                订单 {} 正在orgin平台自动购买中，目前还未完成支付!
                <a href="http://127.0.0.1:5000/">返回登录页面继续购买</a>
                <a href="http://127.0.0.1:5000/checkorderstatus">继续查询订单购买状态</a>
            '''.format(ordernumber)
    elif orderstatus == "afterpay":
        return '''
                订单 {} 正在orgin平台自动购买中，已经完成支付！
                <a href="http://127.0.0.1:5000/">返回登录页面继续购买</a>
                <a href="http://127.0.0.1:5000/checkorderstatus">继续查询订单购买状态</a>
            '''.format(ordernumber)
    elif orderstatus == "finish":
        return '''
                订单 {} 正在orgin平台自动购买中，已经完成支付，成功购买!
                <a href="http://127.0.0.1:5000/">返回登录页面继续购买</a>
                <a href="http://127.0.0.1:5000/checkorderstatus">继续查询订单购买状态</a>
            '''.format(ordernumber)
    elif orderstatus == "nomoney":
        return '''
                订单 {} 购买失败!所有账户资金余额不足，请联系xxx处理!
                <a href="http://127.0.0.1:5000/">返回登录页面继续购买</a>
                <a href="http://127.0.0.1:5000/checkorderstatus">继续查询订单购买状态</a>
            '''.format(ordernumber)
    else:
        return '''
                您所查询的订单 {} 不存在 !
                <a href="http://127.0.0.1:5000/">返回登录页面继续购买</a>
                <a href="http://127.0.0.1:5000/checkorderstatus">继续查询订单购买状态</a>
                '''.format(ordernumber)

# def startApp():
#     app.run(debug=True)

# def buy():
#     while True:
#         if not taskQueue.empty():
#             (account, ordernumber, product, driver, wait) = taskQueue.get()
#             buyProcess(account, ordernumber, product, driver, wait)

#根据/logout调用的地方时：在登录成功以后，由于订单的各种问题还没有开始正式的购买，所以在这个阶段需要自动的在账号追踪账户的信息
@app.route('/logout')
def logout():
    # remove the username from the session if it's there # #
    try:
        AutoDB.buytrace_deletebuyer(session['username'])
    except:
        autobuyLogger.info("在订单号出现问题，客户点击终止重新购买,删除追踪账户中的信息 失败!")
    session.pop('username', None)
    session.clear()
    return redirect(url_for('home'))

if __name__ == '__main__':
    http_server = WSGIServer(('127.0.0.1', 5000), app)
    http_server.serve_forever()

