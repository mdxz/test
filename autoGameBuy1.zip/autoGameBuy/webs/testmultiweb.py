#!/usr/bin/env python
#-*- coding:utf-8 -*-

from gevent import monkey
from gevent.pywsgi import WSGIServer
monkey.patch_all()
from flask import Flask
from flask import redirect,url_for
import time

app = Flask(__name__)

@app.route('/test',methods=['GET'])
def sayHello():
    # time.sleep(10)
    redirect(url_for('hi', filename="good"))

    return 'hello'
    # return (redirect(url_for('show', filename=filename)))

@app.route('/hi',methods=['GET'])
def sayHi():
    return 'hi'
if __name__ =='__main__':
    # http_server = WSGIServer(app)
    http_server = WSGIServer(('127.0.0.1', 5000), app)
    http_server.serve_forever()