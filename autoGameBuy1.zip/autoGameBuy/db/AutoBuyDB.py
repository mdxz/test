#!/usr/bin/env python
#-*- coding:utf-8 -*-

import pymysql
import time
from tools.controltime import (timestampToTime)
from conf.config import (MYSQL_LOCAL_HOST,MYSQL_LOCAL_PORT,MYSQL_LOCAL_USER,MYSQL_LOCAL_PASSWD,MYSQL_LOCAL_DB,MYSQL_LOCAL_CHARSET)
from logger.log import autobuyLogger

class AutoGameBuyDB():
    def __init__(self):
        """
        初始化数据库操作：建立数据库链接，获得数据库游标
        """
        self.conn = pymysql.connect(host=MYSQL_LOCAL_HOST, port=MYSQL_LOCAL_PORT, user=MYSQL_LOCAL_USER,
                                    password=MYSQL_LOCAL_PASSWD, db=MYSQL_LOCAL_DB, charset=MYSQL_LOCAL_CHARSET)
        self.cursor = self.conn.cursor()
        # self.commit = self.conn.commit()

    #为了避免重复购买，在某个单号进行购买前，首先查看该单号在 orderinfors 表中的状态：在购买之前被调用:not
    def orderInfor_checkOrderInfor(self, ordernumber):
        """
        该函数实现的是在orderinfors表中查询某个单号的信息:操作的表是：orderinfors
        :param ordernumber: 需要查询的单号
        :return: 返回的查询信息：若单号已经处在成功购买(成功)或是正在购买中则不再需要购买，若不存在单号或是之前的购买失败，则可以再次购买
                  内容为： (订单号，购买的状态，备注信息)
        """
        outcome = ""
        sql = "select ordernumber, productinfor, buyer, starttime,finishtime, orderstatus, backupinfor from orderinfors where ordernumber = \"%s\";" % (ordernumber)
        autobuyLogger.info("AutoBuyDB:orderInfor_checkOrderInfor:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            outcome = self.cursor.fetchall()
            autobuyLogger.info("AutoBuyDB:orderInfor_checkOrderInfor:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:orderInfor_checkOrderInfor:失败！")
        # 返回查询到的结果,如果没有查询到对应的结果的话，outcome为空字符串,如果有的话是一个列表形式的？？？？：判断的时候首先判断的是否是空字符串
        return  outcome

    #保存购买的开始信息:该函数的调用地方在：从web端传入的开始购买开始:ok
    def orderInfor_saveBuyProcessStartStatus(self,ordernumber, productinfor, buyer, orderstatus, backupinfor):
        """
        该函数的作用的是保存订单的初始状态：操作的表是：orderinfors
        :param ordernumber: 订单号
        :param productinfor: 产品信息
        :param buyer: 订单归属者
        :param orderstatus: 订单购买状态： 失败，完成，进行中!
        :param backupinfo: 订单备注信息： 失败时：指向失败的环节及原因 成功时：保存订单信息和统计信息
        :return:返回的是本次的操作是否成功，成功为1，失败为0
        """
        starttime = timestampToTime(time.time())
        finishtime = starttime
        outcome = 0
        sql  = "insert into  orderinfors (ordernumber,productinfor,buyer,starttime,finishtime,orderstatus,backupinfor) values (\"{}\",\"{}\",\"{}\",\"{}\",\"{}\",\"{}\",\"{}\");".format(ordernumber,productinfor,buyer,starttime,finishtime,orderstatus,backupinfor)
        autobuyLogger.info("AutoBuyDB:orderInfor_saveBuyProcessStartStatus:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            outcome = 1
            autobuyLogger.info("AutoBuyDB:orderInfor_saveBuyProcessStartStatus:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:orderInfor_saveBuyProcessStartStatus:失败！")
            autobuyLogger.info( "AutoBuyDB:orderInfor_saveBuyProcessStartStatus:outcome={outcome}".format(outcome=outcome))
        return outcome

    #更新购买状态操作函数:在确定订单，账号，密码等没有问题之后，开始购买的过程中被调用:ok
    def orderInfor_updateOrderDBInfor(self,ordernumber, orderstatus, backupinfo):
        """
        该函数实现在购买过程中不断的更新某个订单的购买状态： 操作的表是：orderinfors
        :param ordernumber: 需要更新状态的订单号
        :param orderstatus: 更新的状态
        :param backupinfo: 更新的备注信息
        :return:返回的是操作是否成功!
        """
        # 这里将每次更新的时间由更新函数内部得到
        finishtime = timestampToTime(time.time())
        sql  = "update orderinfors set finishtime=\"{}\",orderstatus=\"{}\",backupinfor=\"{}\" where ordernumber=\"{}\";".format(finishtime,orderstatus,backupinfo,ordernumber)
        outcome = 0
        autobuyLogger.info("AutoBuyDB:orderInfor_updateOrderDBInfor:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            outcome = 1
            autobuyLogger.info(
                "AutoBuyDB:orderInfor_updateOrderDBInfor:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:orderInfor_updateOrderDBInfor:失败！")
            autobuyLogger.info(
                "AutoBuyDB:orderInfor_updateOrderDBInfor:outcome={outcome}".format(outcome=outcome))
        return outcome

    #查看所有的订单信息：该函数调用的地方在于：后台网站调用查看订单信息是被调用:not
    def orderInfor_checkAllOrderInfor(self):
        """
        该函数实现的是查看所有的订单信息
        :return: 返回所有的信息
        """
        outcome = ""
        sql = "select * from orderinfors;"
        autobuyLogger.info("AutoBuyDB:orderInfor_checkAllOrderInfor:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            outcome = self.cursor.fetchall()
            autobuyLogger.info("AutoBuyDB:orderInfor_checkAllOrderInfor:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:orderInfor_checkAllOrderInfor:失败！")
            autobuyLogger.info("AutoBuyDB:orderInfor_checkAllOrderInfor:outcome={outcome}".format(outcome=outcome))
            # 返回查询到的结果,如果没有查询到对应的结果的话，outcome为空字符串,如果有的话是一个列表形式的？？？？：判断的时候首先判断的是否是空字符串
        return outcome

    #向数据库插入支付账户的信息：要么集成到后台网站，要么可以单独的函数操作:not
    def payAccountInfo_insertPaymentAccountInfor(self, account, passowrd, safecode):
        """
        该函数实现的是向支付账户表中插入账户信息
        :param account: 账号
        :param passowrd: 密码
        :param safecode: 安全代码
        :return: 返回的是操作是否成功:成功为1，失败为0
        """
        outcome = 0
        sql = "insert into payaccountinfor(account,password,safecode) values (\"{}\",\"{}\",\"{}\");".format(account,passowrd,safecode)
        autobuyLogger.info("AutoBuyDB:payAccountInfo_insertPaymentAccountInfor:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            outcome = 1
            autobuyLogger.info(
                "AutoBuyDB:payAccountInfo_insertPaymentAccountInfor:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:payAccountInfo_insertPaymentAccountInfor:失败！")
            autobuyLogger.info(
                "AutoBuyDB:payAccountInfo_insertPaymentAccountInfor:outcome={outcome}".format(outcome=outcome))
        return outcome

    #获得所有的支付账户信息：调用的地方： 集成到后台，单独的函数操作，在autoBuy的里面 ：ok
    def payAccountInfo_getPaymentAccountInfor(self):
        """
        该函数实现的是返回所有的可用支付账号信息
        :return: 成功返回的是支付账号相关信息，失败返回空字符串
        """
        outcome = ""
        sql = "select * from  payaccountinfor;"
        autobuyLogger.info("AutoBuyDB:payAccountInfo_getPaymentAccountInfor:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            outcome = self.cursor.fetchall()
            autobuyLogger.info("AutoBuyDB:payAccountInfo_getPaymentAccountInfor:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:payAccountInfo_getPaymentAccountInfor:失败！")
            autobuyLogger.info("AutoBuyDB:payAccountInfo_getPaymentAccountInfor:outcome={outcome}".format(outcome=outcome))
            # 返回查询到的结果,如果没有查询到对应的结果的话，outcome为空字符串,如果有的话是一个列表形式的？？？？：判断的时候首先判断的是否是空字符串
        return outcome

    #实现删除数据库中的某些账户信息：集成到后天，或是单独函数操作:not
    def payAccountInfo_deletAccount(self,account):
        """
        该函数实现删除某个特定账户信息
        :param account: 账号
        :return: 返回操作结果成功或是失败：成功返回1，失败返回0
        """
        outcome = 0
        sql = "delete  from payaccountinfor where account=\"{}\";".format(account)
        autobuyLogger.info("AutoBuyDB:payAccountInfo_deletAccount:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            outcome = 1
            autobuyLogger.info(
                "AutoBuyDB:payAccountInfo_deletAccount:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:payAccountInfo_deletAccount:失败！")
            autobuyLogger.info( "AutoBuyDB:payAccountInfo_deletAccount:outcome={outcome}".format(outcome=outcome))
        return outcome

####################################################################

    #管理账户添加：后台或是但单独操作:not
    def pemissonAccountInfo_insertUser(self,username,password):
        """
        添加后台操作账户
        :param username:账号
        :param password: 密码
        :return: 返回操作的状态:成功为1，失败为0
        """
        outcome = 0
        sql = "insert into permissonaccount(username,password) values (\"{}\",\"{}\");".format(username, password)
        autobuyLogger.info("AutoBuyDB:pemissonAccountInfo_insertUser:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            outcome = 1
            autobuyLogger.info(
                "AutoBuyDB:pemissonAccountInfo_insertUser:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:pemissonAccountInfo_insertUser:失败！")
            autobuyLogger.info(
                "AutoBuyDB:pemissonAccountInfo_insertUser:outcome={outcome}".format(outcome=outcome))
        return outcome

    #管理账户的删除:后台或是单独操作:not
    def pemissonAccountInfo_deleteUser(self,username):
        """
        删除特定用户
        :param username: 待删除用户的username
        :return:返回操作的状态，成功为1，失败为0
        """
        outcome = 0
        sql = "delete  from permissonaccount where account=\"{}\";".format(username)
        autobuyLogger.info("AutoBuyDB:pemissonAccountInfo_deleteUser:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            outcome = 1
            autobuyLogger.info(
                "AutoBuyDB:pemissonAccountInfo_deleteUser:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:pemissonAccountInfo_deleteUser:失败！")
            autobuyLogger.info("AutoBuyDB:pemissonAccountInfo_deleteUser:outcome={outcome}".format(outcome=outcome))
        return outcome

    #管理账户的查看：后台或是单独操作:Not：查看所有的账户
    def pemissonAccountInfo_checkUserInfo(self):
        """
        该函数实现的是查看所有的管理账户信息
        :return: 返回所有的管理账户信息：成功返回所有的管理账户，失败返回空""
        """
        outcome = ""
        sql = "select * from  permissonaccount;"
        autobuyLogger.info("AutoBuyDB:pemissonAccountInfo_checkUserInfo:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            outcome = self.cursor.fetchall()
            autobuyLogger.info(
                "AutoBuyDB:pemissonAccountInfo_checkUserInfo:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:pemissonAccountInfo_checkUserInfo:失败！")
            autobuyLogger.info(
                "AutoBuyDB:pemissonAccountInfo_checkUserInfo:outcome={outcome}".format(outcome=outcome))
            # 返回查询到的结果,如果没有查询到对应的结果的话，outcome为空字符串,如果有的话是一个列表形式的？？？？：判断的时候首先判断的是否是空字符串
        return outcome

    #管理账户判断：判断管理账户中是否有某个账号，以便决定某个账户是否有管理的权限
    def pemissonAccountInfo_judgeAccount(self,username,password):
        outcome = ""
        sql = "select * from  permissonaccount where username=\"{}\" and password=\"{}\";".format(username,password)
        autobuyLogger.info("AutoBuyDB:pemissonAccountInfo_judgeAccount:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            outcome = self.cursor.fetchall()
            autobuyLogger.info(
                "AutoBuyDB:pemissonAccountInfo_judgeAccount:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:pemissonAccountInfo_judgeAccount:失败！")
            autobuyLogger.info(
                "AutoBuyDB:pemissonAccountInfo_checkUserInfo:outcome={outcome}".format(outcome=outcome))
            # 返回查询到的结果,如果没有查询到对应的结果的话，outcome为空字符串,如果有的话是一个列表形式的？？？？：判断的时候首先判断的是否是空字符串
        return outcome

################################################################################


    # 保存初始跟踪信息
    def buytarce_savebuytrace(self,buyer,productinfor,ordernumber,orderstatus,backupinfo):
        # starttime = timestampToTime(time.time())
        starttime = time.time()
        finishtime = starttime
        outcome = 0
        sql = "insert into  buytrace (buyer,productinfor,ordernumber,starttime,finishtime,orderstatus,backupinfo,oneflag,fiveflag) values (\"{}\",\"{}\",\"{}\",\"{}\",\"{}\",\"{}\",\"{}\",{},{});".format(buyer, productinfor, ordernumber, starttime, finishtime, orderstatus, backupinfo,0,0)
        autobuyLogger.info("AutoBuyDB:buytarce_savebuytrace:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            outcome = 1
            self.conn.commit()
            autobuyLogger.info(
                "AutoBuyDB:buytarce_savebuytrace:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:buytarce_savebuytrace:失败！")
            autobuyLogger.info(
                "AutoBuyDB:buytarce_savebuytrace:outcome={outcome}".format(outcome=outcome))
        return outcome
    # 更新购买跟踪信息
    def buytrace_updatebuytrace(self,buyer,ordernumber,productinfor,orderstatus,backupinfo):
        # 这里将每次更新的时间由更新函数内部得到
        finishtime = timestampToTime(time.time())
        sql = "update buytrace set finishtime=\"{}\",orderstatus=\"{}\",ordernumber=\"{}\", backupinfo=\"{}\" where buyer=\"{}\";".format(
            finishtime, orderstatus, ordernumber,backupinfo, buyer)
        outcome = 0
        autobuyLogger.info("AutoBuyDB:buytrace_updatebuytrace:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            outcome = 1
            autobuyLogger.info(
                "AutoBuyDB:buytrace_updatebuytrace:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:buytrace_updatebuytrace:失败！")
            autobuyLogger.info(
                "AutoBuyDB:buytrace_updatebuytrace:outcome={outcome}".format(outcome=outcome))
        return outcome
    # 查看账号一分钟之内的登录购买情况:查看的条件是现在时间和starttiem时间之间的差值在1分钟到1分半之间：由于是有检测线程来查看，所以没有参数：
    #调用的地方为检测线程
    #注意转换时间格式
    #后面的几个函数都要注意这种情况
    def buytrace_oneminitescheck(self):

        timeNow = time.time()
        outcome = ""
        # sql = "select buyer,productinfor,orderstatus,backupinfo from buytrace where {}-starttime > 60 and {}-starttime<90 and oneflag=0;".format(timeNow,timeNow)
        sql = "select buyer,productinfor,orderstatus,backupinfo from buytrace where {}-starttime > 60 and oneflag=0;".format(timeNow,timeNow)
        autobuyLogger.info("AutoBuyDB:buytrace_oneminitescheck:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            outcome = self.cursor.fetchall()
            autobuyLogger.info("AutoBuyDB:buytrace_oneminitescheck:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:buytrace_oneminitescheck:失败！")
            autobuyLogger.info("AutoBuyDB:buytrace_oneminitescheck:outcome={outcome}".format(outcome=outcome))
            # 返回查询到的结果,是满足时间条件的账号相关信息：然后检查线程拿到信息以后挨个的发送邮件到对应的账户中
        return outcome

    #当一分钟左右发送邮件以后，重置oneflag=1
    def buytrace_resetoneflag(self,buyer):
        outcome = 0
        sql = "update buytrace set oneflag=1 where buyer=\"{}\";".format(buyer)
        autobuyLogger.info("AutoBuyDB:buytrace_resetoneflag:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            outcome = 1
            autobuyLogger.info("AutoBuyDB:buytrace_resetoneflag:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:buytrace_resetoneflag:失败！")
            autobuyLogger.info("AutoBuyDB:buytrace_resetoneflag:outcome={outcome}".format(outcome=outcome))
            # 返回查询到的结果,是满足时间条件的账号相关信息：然后检查线程拿到信息以后挨个的发送邮件到对应的账户中
        return outcome

    #当5分钟左右发送邮件以后，重置fiveflag=5
    def buytrace_resetfiveflag(self,buyer):
        outcome = 0
        sql = "update buytrace set fiveflag=1 where buyer=\"{}\";".format(buyer)
        autobuyLogger.info("AutoBuyDB:buytrace_resetfiveflag:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            outcome = 1
            autobuyLogger.info("AutoBuyDB:buytrace_resetfiveflag:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:buytrace_resetfiveflag:失败！")
            autobuyLogger.info("AutoBuyDB:buytrace_resetfiveflag:outcome={outcome}".format(outcome=outcome))
            # 返回查询到的结果,是满足时间条件的账号相关信息：然后检查线程拿到信息以后挨个的发送邮件到对应的账户中
        return outcome

    def buytrace_fiveminitescheck(self):
        timeNow = time.time()
        outcome = ""
        # sql = "select buyer,orderstatus,backupinfo from buytrace where {}-starttime > 300 and {}-starttime<330 and fiveflag=0;".format(timeNow,timeNow)
        sql = "select buyer,productinfor,orderstatus,backupinfo from buytrace where {}-starttime > 300  and fiveflag=0;".format(timeNow,timeNow)
        autobuyLogger.info("AutoBuyDB:buytrace_fiveminitescheck:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            outcome = self.cursor.fetchall()
            autobuyLogger.info("AutoBuyDB:buytrace_fiveminitescheck:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:buytrace_fiveminitescheck:失败！")
            autobuyLogger.info("AutoBuyDB:buytrace_fiveminitescheck:outcome={outcome}".format(outcome=outcome))
            # 返回查询到的结果,是满足时间条件的账号相关信息：然后检查线程拿到信息以后挨个的发送邮件到对应的账户中
        return outcome

        # 删除购买跟踪信息：根据账户名

    #该函数实现的是每隔半个小时清理返回一次需要清除的跟踪数据表中的名单信息：单纯的依据30分钟作为唯一的依据
    def buytrace_halfhourscheck(self):
        timeNow = time.time()
        outcome = ""
        sql = "select buyer from buytrace where {}-starttime > 1800;".format(timeNow)
        autobuyLogger.info("AutoBuyDB:buytrace_twohourscheck:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            outcome = self.cursor.fetchall()
            autobuyLogger.info("AutoBuyDB:buytrace_twohourscheck:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:buytrace_twohourscheck:失败！")
            autobuyLogger.info("AutoBuyDB:buytrace_twohourscheck:outcome={outcome}".format(outcome=outcome))
            # 返回查询到的结果,是满足时间条件的账号相关信息：然后检查线程拿到信息以后挨个的发送邮件到对应的账户中
        return outcome

        # 删除购买跟踪信息：根据账户名

    def buytrace_deletebuyer(self,buyer):
        outcome = ""
        sql = "delete from buytrace where buyer=\"{}\";".format(buyer)
        autobuyLogger.info("AutoBuyDB:buytrace_deletebuyer:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            outcome = 1
            autobuyLogger.info("AutoBuyDB:buytrace_deletebuyer:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:buytrace_deletebuyer:失败！")
            autobuyLogger.info("AutoBuyDB:buytrace_deletebuyer:outcome={outcome}".format(outcome=outcome))
            # 返回查询到的结果,是满足时间条件的账号相关信息：然后检查线程拿到信息以后挨个的发送邮件到对应的账户中
        return outcome

    def buytrace_checkbuyer(self,buyer):
        outcome = ""
        sql = "select * from buytrace where buyer=\"{}\";".format(buyer)
        autobuyLogger.info("AutoBuyDB:buytrace_deletebuyer:sql={sql}".format(sql=sql))
        try:
            self.cursor.execute(sql)
            outcome = self.cursor.fetchall()
            autobuyLogger.info("AutoBuyDB:buytrace_deletebuyer:outcome={outcome}".format(outcome=outcome))
        except:
            autobuyLogger.error("AutoBuyDB:buytrace_deletebuyer:失败！")
            autobuyLogger.info("AutoBuyDB:buytrace_deletebuyer:outcome={outcome}".format(outcome=outcome))
            # 返回查询到的结果,是满足时间条件的账号相关信息：然后检查线程拿到信息以后挨个的发送邮件到对应的账户中
        return outcome








AutoDB = AutoGameBuyDB()

if __name__ == '__main__':
    AutoDB.buytarce_savebuytrace("1241697400@qq.com","暂无","暂无","购买进行中","启动Orgin平台登录!")