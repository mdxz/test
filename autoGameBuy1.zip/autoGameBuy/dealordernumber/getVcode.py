#!/usr/bin/env python
#-*- coding:utf-8 -*-

# python3.6.5
# 需要引入requests包 ：运行终端->进入python/Scripts ->输入：pip install requests
from dealordernumber.ShowapiRequest import ShowapiRequest
import base64
import json

def getVcode(image):
    #关键码
    appid = "82667"
    appsecret = "113e9d07c92d4bc5a79c8f018e75d3ad"
    #获得图片的base64字符串
    base64img = ""
    with open(image, "rb") as imageFile:
        base64img = base64.b64encode(imageFile.read())

    r = ShowapiRequest("http://route.showapi.com/184-5",appid,appsecret)
    r.addBodyPara("img_base64", base64img)
    r.addBodyPara("typeId", "16")
    r.addBodyPara("convert_to_jpg", "0")
    r.addBodyPara("needMorePrecise", "0")
    # r.addFilePara("img", r"D:\anti_software\autoGameBuy\pictures\temptab.png") #文件上传时设置
    response = r.post()
    print(response.text) # 返回信息

    vnumber = json.loads(response.text).get("showapi_res_body").get("Result")
    return  vnumber
if __name__ == '__main__':
    image = "D:\\anti_software\\autoGameBuy\\pictures\\capture_2.png"
    vnumber = getVcode(image)
    print("vnumber = {}".format(vnumber))