import time
import hashlib
import urllib
import hmac
import requests

AK = "92d4a737850a5912375cf17dfb994e2c2674fcc1973e3c93feacbd080b0429bd"
SK = "58ed099c7887cbbd1e687486bf6f9fee5dd57d2a9510b74af31c23d2a1ffc2ab"
# SK = '1234567'
timestamp = str(int(time.time()))
uuid = timestamp


def GetSignString(url, method, ts, uuid):
    tmpstr = url.replace("%20", " ")
    print(tmpstr)
    sinStr = method.upper() + '\n'
    sinStr = sinStr + urllib.parse.quote(tmpstr.encode('utf-8'), 'replace').lower().replace("%20", "+") + '\n'
    sinStr = sinStr + "x-jsb-sdk-req-timestamp:" + ts + '\n'
    sinStr = sinStr + "x-jsb-sdk-req-uuid:" + uuid + '\n'
    return sinStr

def Hmacsha256(data, key):
    mac = hmac.new(key, data.encode("utf-8"), digestmod=hashlib.sha256).hexdigest()
    return mac

def getSignatureKey(A, uuid, sk):
    # 计算摘要
    sha1 = hashlib.sha1(A.encode("utf-8"))
    hexDigest = sha1.hexdigest()
    print(hexDigest)
    # 使用SK加密UUID，得到一个新秘钥
    kserect = ('JSB4' + sk).encode('utf-8')
    # kreqid = hmac.new(uuid, kserect, digestmod=hashlib.sha256).digest()
    kreqid = Hmacsha256(uuid, kserect)
    print(kreqid)
    # 使用新秘钥对摘要进行加密
    kSigning = Hmacsha256(hexDigest, bytearray.fromhex(kreqid))
    return kSigning

def TradeSoldGet():
    #获取所有的订单信息
    # url = "https://www.jishibao.top/rest/trade/TradesSoldGetRequest?fields=status,tid&start_created=2018-10-01 00:00:00&"
    #获取增量
    # url = "https://www.jishibao.top/rest/trade/TradesSoldIncrementGetRequest?fields=tid&start_modified=2018-12-01 12:00:00&end_modified=2018-12-01 12:30:00"
    #某个具体订单信息
    url = "https://www.jishibao.top/rest/trade/TradeFullinfoGetRequest?fields=tid,type,status,payment,orders&tid=277403010627279374"
    strsign = GetSignString(url, "get", timestamp, uuid)
    print(strsign)
    sign = getSignatureKey(strsign, uuid, SK)
    print(sign)
    Authorization = 'Credential=' + AK + ',SignedHeaders=x-jsb-sdk-req-timestamp;x-jsb-sdk-req-uuid,Signature=' + sign
    headers = {
        'x-jsb-sdk-req-timestamp' : timestamp,
        'x-jsb-sdk-req-uuid' : uuid,
        'Authorization' : Authorization
    }
    datas = {
        "fields":"tid"
    }

    # response = requests.get(url = url, headers = headers, timeout=5, params=datas, verify=False)
    response = requests.get(url = url, headers = headers, timeout=5, verify=False)
    response.encoding = "utf-8"
    print(response.text)



if __name__ == '__main__':
    TradeSoldGet()